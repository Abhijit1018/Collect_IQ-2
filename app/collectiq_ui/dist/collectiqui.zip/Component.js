sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("collectiqui.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map